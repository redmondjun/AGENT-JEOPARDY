"""
TEMPORARY LOCAL STUB — DO NOT COMMIT THIS FILE.

This is a byte-for-byte copy of the frozen interfaces defined in
TEAM_PLAN.md section 5 ("Frozen Cross-Team Contracts"). contracts.py is
Nandh's file and is not yet merged into main. This stub exists only so
solver/ can be written, imported, and unit-tested locally.

Delete this file the moment the real contracts.py lands on main, and
re-run the solver test suite against it unchanged. If the real file
diverges from this stub in any way, that's a signal the contract
changed out from under solver/ — raise it in the group per section 12
("Contract changes require all four teammates to acknowledge").
"""

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Literal, Mapping, Protocol

AnswerFormat = Literal["exact", "exact_ci", "numeric", "literal", "validator"]


@dataclass(frozen=True)
class TaskContext:
    task_id: str
    category: str
    points: int
    prompt: str
    answer_format: AnswerFormat
    workdir: Path
    files: tuple[Path, ...]
    deadline_monotonic: float
    metadata: Mapping[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class ToolRequest:
    name: str
    arguments: Mapping[str, Any]
    timeout_seconds: float


@dataclass(frozen=True)
class ToolResult:
    ok: bool
    output: str
    error_code: str | None = None
    elapsed_ms: int = 0
    exact_value: str | None = None


@dataclass(frozen=True)
class CandidateAnswer:
    value: str
    confidence: float
    evidence: tuple[str, ...]
    strategy: str
    exact_value_from_tool: bool = False


@dataclass(frozen=True)
class SolveResult:
    candidate: CandidateAnswer | None
    retryable: bool
    failure_code: str | None = None
    retry_after_seconds: float | None = None


class Tool(Protocol):
    name: str

    def execute(self, request: ToolRequest, task: TaskContext) -> ToolResult: ...


class TileSolver(Protocol):
    def solve(self, task: TaskContext) -> SolveResult: ...
