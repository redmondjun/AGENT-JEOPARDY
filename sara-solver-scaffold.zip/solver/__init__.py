from solver import specialists  # noqa: F401  (registers category verification checks)
